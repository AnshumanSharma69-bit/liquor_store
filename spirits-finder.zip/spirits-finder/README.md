# 🍾 Spirits Finder

A PWA compass app that points to the nearest liquor store near you.

## Features
- 📍 Live GPS compass needle pointing to the nearest store
- 📸 Street view / store photo
- ☎️ Tap to call
- 🗺️ One-tap directions (Google Maps)
- 🌐 Store website link
- 🟢 Open / Closed badge with live hours
- 📋 List of 5 nearest stores (tap to switch)
- 📲 Installable as a PWA (Add to Home Screen)

## Deploy to Vercel

### Option 1 — Drag & Drop (fastest)
1. Go to [vercel.com](https://vercel.com) → New Project
2. Drag this entire folder into the upload area
3. Click Deploy — done ✅

### Option 2 — GitHub
1. Push this folder to a GitHub repo
2. Import it on Vercel
3. Deploy with zero config

## Adding App Icons
Put your icon files in the `/icons/` folder:
- `icon-192.png` (192×192 px)
- `icon-512.png` (512×512 px)

You can generate them free at: https://realfavicongenerator.net

## API
Uses Google Maps Places API via RapidAPI.
Replace the key in `app.js` line 2 if needed:
```js
const KEY = 'your-rapidapi-key-here';
```
